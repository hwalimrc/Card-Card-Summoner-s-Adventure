﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class EnemyBattleRecord : MonoBehaviour
{
    public Text battleRecordLable;
    // Start is called before the first frame update
    void Start()
    {
        battleRecordLable = GetComponent<Text>();
    }

    // Update is called once per frame
    void Update()
    {
        battleRecordLable.text = Enemy.attackedType;
    }
}
