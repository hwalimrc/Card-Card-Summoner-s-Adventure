﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using System.IO;

public class Player : MonoBehaviour
{
    public static float playerFullHP = 700;
    public static float playerCurrentHP;
    public static int cardMatched = 0;
    public static int limitedCard = 0;
    public Slider hpSlider;

    // Start is called before the first frame update
    void Start()
    {
        Load();
        Debug.Log(playerCurrentHP);
    }

    // Update is called once per frame
    void Update()
    {
        hpSlider.maxValue = playerFullHP;
        hpSlider.value = playerCurrentHP;
    }

    void Load()
    {
        PlayerPrefs.GetFloat("HP", playerCurrentHP);
        PlayerPrefs.GetFloat("CardMatched", cardMatched);
        PlayerPrefs.GetFloat("Limited", limitedCard);
    }
}
