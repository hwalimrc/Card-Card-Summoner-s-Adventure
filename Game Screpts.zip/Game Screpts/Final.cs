﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Final : MonoBehaviour
{
    GUIText txt;
    private int totalScore;
    // Start is called before the first frame update
    void Start()
    {
        txt = GetComponent<GUIText>();
        totalScore = 100 * (StageSysytem.meatEnemy + Player.cardMatched) + 110 * Player.limitedCard;
        txt.text =
            "Kill Enemy: " +StageSysytem.meatEnemy+ "\n" +
            "Card Mached: " + Player.cardMatched + "\n" +
            "Get Limited Card: " + Player.limitedCard + "\n" +
            "Total Score: " + totalScore;
    }
}
