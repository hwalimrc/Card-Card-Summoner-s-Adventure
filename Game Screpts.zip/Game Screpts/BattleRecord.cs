﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class BattleRecord : MonoBehaviour
{
    public Text battleRecordLable;
    // Start is called before the first frame update
    void Start()
    {
        battleRecordLable = GetComponent<Text>();
    }

    // Update is called once per frame
    void Update()
    {
        battleRecordLable.text = GameSystem.battleRecord;
    }
}
