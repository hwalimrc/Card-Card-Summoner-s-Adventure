﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
public class TitleGUI : MonoBehaviour
{
    public GUISkin customSkin;

    // Start is called before the first frame update
    void Start()
    {

    }

    // Update is called once per frame
    private void OnGUI()
    {
        GUI.skin = customSkin;
        int buttonWidth = 300, buttonHeight = 50; // 버튼의 폭, 높이
        float halfScreen = Screen.width / 2, halfButton = buttonWidth / 2;

        if (GUI.Button(new Rect(halfScreen - halfButton, Screen.height - buttonHeight * 2, buttonWidth, buttonHeight), "Game Start"))
        {
            SceneManager.LoadScene("Game Stage");
        }
    }
}
