﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.IO;
using UnityEngine.SceneManagement;

public class ButtonEvent : MonoBehaviour
{
    public GameObject panel_1;
    public GameObject panel_2;
    public GameObject panel_3;
    public GameObject panel_4;

    void Start()
    {
        Cursor.lockState = CursorLockMode.None;
        Cursor.visible = true;

        panel_1.SetActive(true);
        panel_2.SetActive(false);
        panel_3.SetActive(false);
        panel_4.SetActive(false);
    }

    public void MainScreen()
    {
        SceneManager.LoadScene("Title Screen");
    }

    public void ExitGame()
    {
        Application.Quit();
    }

    public void GameGuide()
    {
        SceneManager.LoadScene("Guide");
    }

    public void GoStage()
    {
        SceneManager.LoadScene("StageLoading");
    }

    public void FirstLoad()
    {
        StageSysytem.meatEnemy = 0;
        LoadingScene.stageNumber = 0;
        SceneManager.LoadScene("StageLoading");
        Player.playerCurrentHP = 700;
        PlayerPrefs.SetFloat("HP", Player.playerCurrentHP);
        PlayerPrefs.Save();
    }

    public void guide_1()
    {
        panel_1.SetActive(false);
        panel_2.SetActive(true);
    }

    public void guide_1_back()
    {
        panel_2.SetActive(false);
        panel_1.SetActive(true);
    }

    public void guide_2()
    {
        panel_2.SetActive(false);
        panel_3.SetActive(true);
    }

    public void guide_2_back()
    {
        panel_3.SetActive(false);
        panel_2.SetActive(true);
    }

    public void guide_3()
    {
        panel_3.SetActive(false);
        panel_4.SetActive(true);
    }

    public void guide_3_back()
    {
        panel_4.SetActive(false);
        panel_3.SetActive(true);
    }
}
