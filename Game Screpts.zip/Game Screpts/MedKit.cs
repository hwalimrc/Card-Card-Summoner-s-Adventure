﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class MedKit : MonoBehaviour
{
    public GameObject medkit;

    private void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.name == "Player")
        {
            if(Player.playerCurrentHP <= 400)
            {
                Player.playerCurrentHP = Player.playerCurrentHP + 200;
            }

            else if(Player.playerCurrentHP >= 400 && Player.playerCurrentHP <= 600)
            {
                Player.playerCurrentHP = 600;
            }
            Destroy(medkit);
        }
    }
}
