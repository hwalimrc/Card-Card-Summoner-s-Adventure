﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using System.IO;
using UnityEngine.SceneManagement;

public class GameSystem : MonoBehaviour
{
    private int cols = 4, rows = 4;
    private static int totalCards;

    private int cardW = 100, cardH = 100;

    List<Card> aCard;
    Card[,] aGrid;
    List<Card> aCardsFlipped;
    bool playerCanClick;
    public static bool playerHasWon;

    public static bool playerTurn;
    public static bool enemyTurn;
    public static bool enemyAttacked;

    public static int playerAttackType;
    public static string battleRecord;

    public GameObject Button;
    public Slider hpSlider;

    // Use this for initialization
    void Start()
    {
        totalCards = 16;
        playerHasWon = false;
        Load();

        Cursor.lockState = CursorLockMode.None;
        Cursor.visible = true;

        Button.SetActive(false);
        
        battleRecord = "start";
        playerCanClick = true;
        playerTurn = true;
        enemyAttacked = false;

        aCard = new List<Card>();
        aGrid = new Card[rows, cols];

        aCardsFlipped = new List<Card>();

        BuildDeck();

        for (int i = 0; i < rows; i++)
        {
            for (int j = 0; j < cols; j++)
            {
                int someNum = Random.Range(0, aCard.Count);
                aGrid[i, j] = aCard[someNum];
                aCard.RemoveAt(someNum);
            }
        }
    }

    void Update()
    {
        EndBattle();
        hpSlider.maxValue = Player.playerFullHP;
        hpSlider.value = Player.playerCurrentHP;

        if (timer.timeOver == true || totalCards == 0)
        {
            playerCanClick = false;

            if ((Player.playerCurrentHP / Player.playerFullHP) * 100 >= 
                (Enemy.enemyHP / Enemy.fullHP) * 100)
            {
                playerHasWon = true;               
            }
            else { SceneManager.LoadScene("Game Over"); }
        }

        if (Player.playerCurrentHP <= 0)
            SceneManager.LoadScene("Game Over");

        if (Enemy.enemyHP <= 0) playerHasWon = true;
    }

    void OnGUI()
    {
        GUILayout.BeginArea(new Rect(0, 0, Screen.width, Screen.height));
        BuildGrid();
        GUILayout.EndArea();
    }

    private void BuildGrid()
    {
        GUILayout.BeginVertical();
        GUILayout.FlexibleSpace();
        for (int i = 0; i < rows; i++)
        {
            GUILayout.BeginHorizontal();
            GUILayout.FlexibleSpace();
            Card card = new Card();         
            for (int j = 0; j < cols; j++)
            {
                card = aGrid[i, j];
                string img;
                if (card.isMatched)
                { img = "blank"; }

                else
                {
                    if (card.isFaceUp)
                    { img = card.img; }

                    else
                    { img = "Back"; }
                }
                GUI.enabled = !card.isMatched;
                if (GUILayout.Button((Texture)Resources.Load(img), GUILayout.Width(cardW)))
                {
                    if (playerCanClick && playerTurn)
                    {
                        //aCardsFlipped.Add(card);
                        FlipCardFaceUp(card);                                           
                    }

                    GUI.enabled = true;
                }
            }
            GUILayout.FlexibleSpace();
            GUILayout.EndHorizontal();
        }
        GUILayout.FlexibleSpace();
        GUILayout.EndVertical();
    }

    private void BuildDeck()
    {
        int totalSkilType = 4;
        Card card;
        int id = 0;

        for (int i = 0; i < totalSkilType; i++)
        {
            List<string> aTypeParts = new List<string> { "atk", "def", "heal", "sop" };
            List<string> aTypeParts2 = new List<string> { "atk 1", "def 1", "heal 1", "sop 1" };
            // 딜링 카드, 방어 카드, 힐링 카드, 서포트 카드

            for (int j = 0; j < 2; j++)
            {
                int someNum = Random.Range(0, aTypeParts.Count);
                string thePartnerPart = aTypeParts[someNum];
                string thePartnerPart2 = aTypeParts2[someNum];

                aTypeParts.RemoveAt(someNum);
                aTypeParts2.RemoveAt(someNum);

                card = new Card("deck" + (i + 1) + thePartnerPart, id);
                aCard.Add(card);

                card = new Card("deck" + (i + 1) + thePartnerPart2, id);
                aCard.Add(card);

                id++;
            }
        }
    }
    void FlipCardFaceUp(Card card)
    {
        card.isFaceUp = true;
        Debug.Log("aCardsFlipped.Count: " + aCardsFlipped.Count);      

        if (aCardsFlipped.IndexOf(card) < 1)
        {
            aCardsFlipped.Add(card);
            if (aCardsFlipped.Count == 2)
            {
                playerCanClick = false;
                StartCoroutine("Wait");
                playerTurn = false;
                enemyTurn = true;
            }
        }
    }
    IEnumerator Wait()
    {        
        yield return new WaitForSeconds(1);

        if (aCardsFlipped[0].id == aCardsFlipped[1].id && aCardsFlipped[0].img != aCardsFlipped[1].img)
        {
            PlayerAttack(aCardsFlipped[1].img);
            aCardsFlipped[0].isMatched = true;
            aCardsFlipped[1].isMatched = true;
            totalCards = totalCards - 2;
            Player.cardMatched++;
        }

        else if(aCardsFlipped[0].img == aCardsFlipped[1].img)
        {
            Debug.Log("불일치");
            aCardsFlipped[0].isFaceUp = false;
            aCardsFlipped[1].isFaceUp = false;
            battleRecord = "중복선택불가";
        }

        else
        {
            Debug.Log("불일치");
            aCardsFlipped[0].isFaceUp = false;
            aCardsFlipped[1].isFaceUp = false;
            battleRecord = "공격이 빗나갔다.";
        }
        aCardsFlipped = new List<Card>();
        playerCanClick = true;       
    }

    public void PlayerAttack(string type)
    {
        enemyAttacked = true;
        // 플레이어가 뽑은 카드의 타입에 따라 구사하는 스킬의 종류가 달라짐.
        if (type.Contains("atk"))
        {
            if (type.Contains("1"))
            {
                Debug.Log("플레이어가 뽑은 카드: 흑마도사");
                playerAttackType = 1;
                battleRecord = "파이어붐";
            }

            if (type.Contains("2"))
            {
                Debug.Log("플레이어가 뽑은 카드: 청마도사");
                playerAttackType = 2;
                battleRecord = "죽음의 선고";
            }

            if (type.Contains("3"))
            {
                Debug.Log("플레이어가 뽑은 카드: 용기사");
                playerAttackType = 3;
                battleRecord = "용의 오른눈";
            }

            if (type.Contains("4"))
            {
                Debug.Log("플레이어가 뽑은 카드: 사무라이");
                playerAttackType = 4;
                battleRecord = "설, 월, 화 (雪月花)";
            }

        }

        else if (type.Contains("heal"))
        {
            if (type.Contains("1"))
            {
                Debug.Log("플레이어가 뽑은 카드: 점성술사");
                playerAttackType = 5;
                Player.playerCurrentHP = Player.playerCurrentHP + 100;
                battleRecord = "별읽기: 베네피크";
            }

            if (type.Contains("2"))
            {
                Debug.Log("플레이어가 뽑은 카드: 학자");
                playerAttackType = 6;
                Player.playerCurrentHP = Player.playerCurrentHP + 80;
                battleRecord = "요정 에오스";
            }

            if (type.Contains("3"))
            {
                Debug.Log("플레이어가 뽑은 카드: 백마도사");
                playerAttackType = 7;
                Player.playerCurrentHP = Player.playerCurrentHP + 120;
                battleRecord = "케알라";
            }

            if (type.Contains("4"))
            {
                Debug.Log("플레이어가 뽑은 카드: 소환사");
                playerAttackType = 8;
                Player.playerCurrentHP = Player.playerCurrentHP + 70;
                battleRecord = "소환: 카벙클 루비";
            }
        }

        else if (type.Contains("def"))
        {
            if (type.Contains("1"))
            {
                Debug.Log("플레이어가 뽑은 카드: 암흑기사");
                playerAttackType = 9;
                battleRecord = "흡혼검";
            }

            if (type.Contains("2"))
            {
                Debug.Log("플레이어가 뽑은 카드: 나이트");
                playerAttackType = 10;
                battleRecord = "결연한 수호자";
            }

            if (type.Contains("3"))
            {
                Debug.Log("플레이어가 뽑은 카드: 전사");
                playerAttackType = 11;
                battleRecord = "최후통첩";
            }

            if (type.Contains("4"))
            {
                Debug.Log("플레이어가 뽑은 카드: 기사신");
                playerAttackType = 12;
                Player.limitedCard++;
                battleRecord = "궁극의 종말";
            }
        }

        else
        {
            if (type.Contains("1"))
            {
                Debug.Log("플레이어가 뽑은 카드: 적마도사");
                playerAttackType = 13;
                battleRecord = "성원";
            }

            if (type.Contains("2"))
            {
                Debug.Log("플레이어가 뽑은 카드: 음유시인");
                playerAttackType = 14;
                battleRecord = "마인의 진혼곡";
            }

            if (type.Contains("3"))
            {
                Debug.Log("플레이어가 뽑은 카드: 기공사");
                playerAttackType = 15;
                battleRecord = "자동포탑: 룩";
            }

            if (type.Contains("4"))
            {
                Debug.Log("플레이어가 뽑은 카드: 바하무트");
                playerAttackType = 16;
                Player.limitedCard++;
                battleRecord = "테라플레어";
            }
        }
    }

    void EndBattle()
    {
        if (playerHasWon)
        {
            Save();
            playerHasWon = false;
            SceneManager.LoadScene("Victory Scene");
        }
    }

    void Save()
    {
        PlayerPrefs.SetFloat("HP", Player.playerCurrentHP);
        PlayerPrefs.SetFloat("CardMatched", Player.cardMatched);
        PlayerPrefs.SetFloat("Limited", Player.limitedCard);
    }

    void Load()
    {
        PlayerPrefs.GetFloat("HP", Player.playerCurrentHP);
        PlayerPrefs.GetFloat("CardMatched", Player.cardMatched);
        PlayerPrefs.GetFloat("Limited", Player.limitedCard);
    }
}

public class Card : Object
{
    public string img;
    public bool isFaceUp = false;
    public bool isMatched = false;
    public int id;

    public Card()
    {
        img = "Back";
    }

    public Card(string img, int id)
    {
        this.img = img;
        this.id = id;
    }
}