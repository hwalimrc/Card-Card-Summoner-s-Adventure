﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class timer : MonoBehaviour
{
    public float time;

    Text timeText;
    public static bool timeOver;

    // Start is called before the first frame update
    void Start()
    {
        time = 60f;
        timeOver = false;
    }

    // Update is called once per frame
    void Update()
    {
        if (time != 0)
        {
            time -= Time.deltaTime;
            if (time <= 0)
                time = 0;
        }
        else timeOver = true;

        int t = Mathf.FloorToInt(time);
        timeText = GetComponent<Text>();
        timeText.text = t.ToString();
    }
}
