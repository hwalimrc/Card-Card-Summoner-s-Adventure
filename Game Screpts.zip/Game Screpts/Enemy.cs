﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Enemy : MonoBehaviour
{
    public static string attackedType;

    public static float enemyHP;
    public static float fullHP = 200;

    private int debuff = 0;
    private int iValue = 5; // 치명타 발생 확률을 위해 사용할 기준값

    public float enemyPower;
    public float enemyHeal;
    public Slider hpSlider;

    // Start is called before the first frame update
    void Start()
    {
        enemyHP = fullHP;
        enemyPower = 30f;
        Debug.Log(enemyHP);
        attackedType = "Start";       
    }

    // Update is called once per frame
    void Update()
    {
        hpSlider.maxValue = fullHP;
        hpSlider.value = enemyHP;

        EnemyAttack();
        EnemyAttacked();
    }

    void EnemyAttack()
    {
        if (GameSystem.enemyTurn == true)
        {
            switch(debuff)
            {
                case 0: // 평상시
                    attackedType = "상대에게 공격을 가함.";
                    Player.playerCurrentHP = Player.playerCurrentHP - enemyPower;
                    GameSystem.enemyTurn = false;
                    GameSystem.playerTurn = true;
                    break;

                case 1: // 상대에게 흡혼검 스킬을 받았을 때.
                    attackedType = "상대에게 공격을 가함.";
                    Player.playerCurrentHP = Player.playerCurrentHP - 10f;
                    debuff = 0;
                    GameSystem.enemyTurn = false;
                    GameSystem.playerTurn = true;
                    break;

                case 2: // 상대에게 결연한 수호자 스킬을 받았을 때.
                    attackedType = "상대에게 공격을 가함.";
                    Player.playerCurrentHP = Player.playerCurrentHP - 0f;
                    debuff = 0;
                    GameSystem.enemyTurn = false;
                    GameSystem.playerTurn = true;
                    break;

                case 3: // 상대에게 최후통첩 스킬을 받았을 때.
                    attackedType = "상대에게 공격을 가함.";
                    Player.playerCurrentHP = Player.playerCurrentHP - 15f;
                    debuff = 0;
                    GameSystem.enemyTurn = false;
                    GameSystem.playerTurn = true;
                    break;

                case 4: // 상대에게 성원 스킬을 받았을 때.
                    attackedType = "상대에게 공격을 가함.";
                    Player.playerCurrentHP = Player.playerCurrentHP - enemyPower;
                    debuff = 0;
                    GameSystem.enemyTurn = false;
                    GameSystem.playerTurn = true;
                    break;

                case 5: // 상대에게 마인의 진혼곡 스킬을 받았을 때.
                    attackedType = "상대에게 공격을 가함.";
                    Player.playerCurrentHP = Player.playerCurrentHP - enemyPower - 10;
                    debuff = 0;
                    GameSystem.enemyTurn = false;
                    GameSystem.playerTurn = true;
                    break;

                default:
                    Debug.Log("default");
                    break;
            }
            
        }
    }

    void EnemyAttacked()
    {                
        if(GameSystem.enemyAttacked == true)
        {
            if (debuff == 4) { enemyHP = enemyHP - 30; }
            if (debuff == 5) { enemyHP = enemyHP - 20; }
            enemyPower = 30;
            switch (GameSystem.playerAttackType)
            {
                case 1: // 플레이어가 뽑은 흑마도사 카드에 의해 공격받은 경우.
                    enemyHP = enemyHP - 100; // 파이어: 적에게 일격을 가한다. (피해량 100)
                    attackedType = "파이어봄 스킬에 의해 \n피해를 입었다.";
                    debuff = 0;
                    break;

                case 2: // 플레이어가 뽑은 청마도사 카드에 의해 공격받은 경우.
                    enemyHP = enemyHP - 80; // 죽음의 선고: 적에게 번개일격을 가한다 (피해량 80)
                    attackedType = "플레이어의 죽음의 선고\n 피해량은 평이했다.";
                    debuff = 0;
                    break;

                case 3: // 플레이어가 뽑은 용기사 카드에 의해 공격받은 경우.
                    enemyHP = enemyHP - 110; // 용의 왼눈: 적에게 강력한 일격을 가한다. (피해량 110)
                    attackedType = "피격: 용의 왼눈";
                    break;

                case 4: // 플레이어가 뽑은 사무라이 카드에 의해 공격받은 경우.
                     // 설,월,화: 적에게 기습공격을 가한다.(50%의 확률로 치명타)
                    if (Random.Range(1, 10) <= iValue)
                    {
                        enemyHP = enemyHP - 120; // 설,월,화 치명타.
                        attackedType = "설,월,화 삼단배기 공격.\n급소에 맞았다!";
                    }
                    else {
                        enemyHP = enemyHP - 60;
                        attackedType = "설,월,화 삼단배기 공격.\n피해량은 평이했다.";
                    }
                    
                    break;

                case 5:
                    attackedType = "상대가 별읽기: 배네피크 스킬을 \n사용하여 체력을 회복합니다";
                    debuff = 0;
                    break;

                case 6:                    
                    attackedType = "요정 에오스가 상대의 체력을\n 회복시킵니다.";
                    debuff = 0;
                    break;

                case 7:
                    attackedType = "상대가 케알라 스킬을 사용하여\n 체력을 회복합니다";
                    debuff = 0;
                    break;

                case 8:
                    attackedType = "상대의 카벙클 루비\n 소환수에게 피해를 받았습니다.";
                    enemyHP = enemyHP - 60;
                    debuff = 0;
                    break;

                case 9:
                    attackedType = "상대의 흡혼검 스킬에 의해\n 공격이 흡수되었습니다.";
                    debuff = 1;
                    break;

                case 10:
                    attackedType = "상대의 결연한 수호자 스킬에 의해 \n 공격이 무효화 되었습니다.";
                    debuff = 2;
                    break;

                case 11:
                    attackedType = "상대의 최후통첩 스킬에 의해 \n 공격이 반감되었습니다";
                    debuff = 3;
                    break;

                case 12:
                    attackedType = "상대의 리미트: 궁극의 종말 스킬로 \n 200의 피해를 입었습니다";
                    enemyHP = enemyHP - 200;
                    break;

                case 13:
                    attackedType = "상대가 성원 스킬을 사용하여\n 다음 턴의 공격을 강화했습니다.";
                    debuff = 4;
                    break;

                case 14:
                    attackedType = "상대의 마인의 진혼곡 스킬에 의해\n 다음 턴의 공격이 약화되었습니다.";
                    debuff = 5;
                    break;

                case 15:
                    attackedType = "상대의 자동포탑: 룩 스킬로\n 50의 피해를 입었습니다";
                    enemyHP = enemyHP - 50;
                    debuff = 0;
                    break;

                case 16:
                    attackedType = "상대의 리미트: 테라플레어\n 스킬로 200의 피해를 입었습니다";
                    enemyHP = enemyHP - 200;
                    debuff = 0;
                    break;
            }
            Debug.Log("적이 공격받았습니다.");
            GameSystem.enemyAttacked = false;
        }
    }
}
