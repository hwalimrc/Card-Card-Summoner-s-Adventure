﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class StageSysytem : MonoBehaviour
{
    public GameObject[] fieldEnemy = new GameObject[6];
    public GameObject[] door = new GameObject[5];

    public Transform[] startPosition = new Transform[6];
    public GameObject PlayerObject; // 플레이어 캐릭터
    public GameObject MonsterUnit; // 일반 NPC 유닛

    public static int[] enemyNumber = new int[6];
    public static int meatEnemy = 0;

    public bool check = true; // 지연처리를 위해 쓰임.

    // Start is called before the first frame update
    void Start()
    {
        Debug.Log("시작");
        Debug.Log(meatEnemy);
        if (LoadingScene.stageNumber == 1)
            StartLocation();
    }

    // Update is called once per frame
    void Update()
    {

    }


    public void StartLocation()
    {
        switch (meatEnemy) // 처치한 적에 따라 스테이지 씬에서 시작하는 지점이 달라야 함.
        {
            case 0:
                PlayerObject.transform.position = startPosition[0].position;
                fieldEnemy[0] = (GameObject)Instantiate(MonsterUnit, startPosition[1]) as GameObject;          
                break;

            case 1:
                PlayerObject.transform.position = startPosition[1].position;
                fieldEnemy[1] = (GameObject)Instantiate(MonsterUnit, startPosition[2]) as GameObject;
                Destroy(door[0]);
                break;

            case 2:
                PlayerObject.transform.position = startPosition[2].position;
                fieldEnemy[2] = (GameObject)Instantiate(MonsterUnit, startPosition[3]) as GameObject;
                Destroy(door[1]);
                break;

            case 3:
                PlayerObject.transform.position = startPosition[3].position;
                fieldEnemy[3] = (GameObject)Instantiate(MonsterUnit, startPosition[4]) as GameObject;
                Destroy(door[2]);
                break;

            case 4:
                PlayerObject.transform.position = startPosition[4].position;
                fieldEnemy[4] = (GameObject)Instantiate(MonsterUnit, startPosition[5]) as GameObject;
                Destroy(door[3]);
                break;

            case 5:
                PlayerObject.transform.position = startPosition[5].position;
                Destroy(door[4]);
                break;

            default:
                break;
        }
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.name == "Player" && LoadingScene.stageNumber == 0)
        {
            LoadingScene.stageNumber++;
            SceneManager.LoadScene("StageLoading");
        }
    }
}
